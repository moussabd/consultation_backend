package sn.project.consultation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
