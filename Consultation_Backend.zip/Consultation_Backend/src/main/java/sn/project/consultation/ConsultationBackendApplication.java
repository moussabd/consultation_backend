package sn.project.consultation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  ConsultationBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConsultationBackendApplication.class, args);
    }

}
