package sn.project.consultation.data.entities;

public enum EtatPaiement {
    NON_PAYEE,
    EN_ATTENTE,
    PAYEE,
    ECHEC
}
