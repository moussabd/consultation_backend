package sn.project.consultation.api.dto;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InfosUrgenceDTO {
    private String couvertureSociale;
    private String personneUrgence;
    private String telPersonneUrgence;
}
