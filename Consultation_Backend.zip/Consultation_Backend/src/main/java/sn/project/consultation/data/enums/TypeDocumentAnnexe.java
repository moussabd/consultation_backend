package sn.project.consultation.data.enums;

public enum TypeDocumentAnnexe {
    CONSENTEMENT_ECLAIRE,
    FICHE_LIAISON,
    ORDONNANCE_SORTIE,
    FICHIER_MEDICAL_ANNEXE
}
