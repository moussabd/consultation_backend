package sn.project.consultation.data.enums;

public enum RoleUser {
    PATIENT, PRO_SANTE, ADMIN
}